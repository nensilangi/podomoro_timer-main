import 'package:flutter/material.dart';
import 'package:pomodoro_timer/screens/home.dart';
import 'package:pomodoro_timer/provider/timer_provider.dart';
import 'package:pomodoro_timer/screens/onboarding.dart';
import 'package:pomodoro_timer/screens/settings.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  final isFirstTime = prefs.getBool('isFirstTime') ?? true;
  runApp(
    ChangeNotifierProvider(
      create: (_) => PomodoroTimer(),
      child: MyApp(isFirstTime: isFirstTime),
    ),
  );
}

class MyApp extends StatelessWidget {
  final bool isFirstTime;
  const MyApp({super.key, required this.isFirstTime});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Pomodoro Timer',
      theme: ThemeData.dark(),
      initialRoute: isFirstTime ? '/onboarding' : '/home',
      routes: {
        '/': (_) => OnboardingScreen(),
        '/onboarding': (_) => OnboardingScreen(),
        '/home': (_) => HomeScreen(),
        '/settings': (_) => SettingsScreen(),
      },
    );
  }
}
