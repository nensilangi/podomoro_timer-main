import 'package:flutter/material.dart';
import 'package:pomodoro_timer/provider/timer_provider.dart';
import 'package:provider/provider.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Consumer<PomodoroTimer>(
          builder:
              (context, timer, child) => Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    timer.phase,
                    style: TextStyle(color: Colors.white, fontSize: 28),
                  ),
                  SizedBox(height: 20),
                  CircularPercentIndicator(
                    circularStrokeCap: CircularStrokeCap.round,
                    radius: 150,
                    lineWidth: 30,
                    arcBackgroundColor: Colors.grey.shade100,
                    arcType: ArcType.FULL,
                    percent: timer.progress,
                    center: Text(
                      timer.formattedTime,
                      style: TextStyle(color: Colors.white, fontSize: 36),
                    ),
                    progressColor: Colors.orange,
                  ),
                  SizedBox(height: 40),
                  IconButton(
                    icon: Icon(
                      timer.isRunning ? Icons.pause : Icons.play_arrow,
                      color: Colors.white,
                      size: 80,
                    ),
                    onPressed: timer.toggleTimer,
                  ),
                ],
              ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.grey,
        currentIndex: 1,
        onTap: (i) {
          if (i == 0) {
            Navigator.pushNamed(context, '/settings');
          }
        },
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'Settings',
          ),
          BottomNavigationBarItem(icon: Icon(Icons.timer), label: 'Timer'),
        ],
      ),
    );
  }
}
