package com.example.pomodoro_timer

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
